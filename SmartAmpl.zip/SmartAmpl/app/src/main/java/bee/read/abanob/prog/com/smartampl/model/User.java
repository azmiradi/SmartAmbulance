package bee.read.abanob.prog.com.smartampl.model;

public class User {
     private String accessToken;
     private String msg;
     private String message;

    public User(String accessToken, String msg, String message) {
        this.accessToken = accessToken;
        this.msg = msg;
        this.message = message;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
