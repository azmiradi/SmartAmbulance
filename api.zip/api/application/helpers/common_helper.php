<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 19-Nov-16
 * Time: 3:07 AM
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

//this will create an array of objects with the first row column headers as the keys
function get_array_of_objects_from_csv_file($filePath){
    //ref: http://php.net/manual/en/function.str-getcsv.php#117692
    $csv = array_map('str_getcsv', file($filePath));
    array_walk($csv, function(&$a) use ($csv) {
        $a = (object)array_combine($csv[0], $a);
    });
    array_shift($csv);# remove column header
    return $csv;
}

function ValidateDate($date, $format = 'Y-m-d H:i:s') {
    $version = explode('.', phpversion());
    if (((int)$version[0] >= 5 && (int)$version[1] >= 2 && (int)$version[2] > 17)) {
        $d = DateTime::createFromFormat($format, $date);
    } else {
        $d = new DateTime(date($format, strtotime($date)));
    }
    return $d && $d -> format($format) == $date;
}

//Display numbers with ordinal suffix ex. convert 1 into 1st 2 into 2nd and so on
function ordinal($number) {
    $ends = array('th','st','nd','rd','th','th','th','th','th','th');
    if ((($number % 100) >= 11) && (($number%100) <= 13))
        return $number. 'th';
    else
        return $number. $ends[$number % 10];
}
/**
�* alidate email format
 * @param string email
 * @return poolean true/false
�*/

function check_email($email) {
    return preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", trim($email));
}
function generate_token($input = '') {
    $source = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $string = $input;
    for ($p = 0; $p < 4; $p++) {
        $string .= $source[mt_rand(0, strlen($source) - 1)];
    }
    return hash('sha1',$string . $input);
}
/**
�* generate random string
�* @param int legnth optional string legnth default 8
 * @param string type optional lower case /numirc/alpha numirc chars pool default alpha numirc
 * @return string random chars
�*/
function generate_string($length = 8, $type = 'all') {
    switch ($type) {
        case 'all' :
            $source = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            break;
        case 'num' :
            $source = "0123456789";
            break;
        case 'low' :
            $source = "abcdefghijklmnopqrstuvwxyz";
            break;
    }
    $string = "";
    for ($p = 0; $p < $length; $p++) {
        $string .= $source[mt_rand(0, strlen($source) - 1)];
    }
    return $string;
}

function post_data($url,$fields=[]) {
    $headers = array('Content-Type: application/json');
    // Open connection
    $ch = curl_init();

    // Set the url, number of POST vars, POST data
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // Disabling SSL Certificate support temporarly
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    //execute curl
    $result = curl_exec($ch);
    if ($result === FALSE) {
        $result = curl_error($ch);
    }
    // Close connection
    curl_close($ch);
    return $result;
}
/**
�* android push notification to an array of gcm_ids
�* @param array string $gcm_ids
�* @param string $message to be sent
�* @param string $google_api_key
 * @return String containing push results
�* @refrence http://stackoverflow.com/questions/25859898/sending-push-notifications-to-multiple-android-devices-using-gcm
�*/
function push_android($gcm_ids, $message, $google_api_key,$moreInfo=array()) {

    $data = array('message' => $message);

    // Set POST variables
    $url = 'https://android.googleapis.com/gcm/send';

    $fields = array('registration_ids' => $gcm_ids, 'data' => $data);

    $headers = array('Authorization: key=' . $google_api_key, 'Content-Type: application/json');
    // Open connection
    $ch = curl_init();

    // Set the url, number of POST vars, POST data
    curl_setopt($ch, CURLOPT_URL, $url);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Disabling SSL Certificate support temporarly
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

    $result = curl_exec($ch);
    if ($result === FALSE) {
        $result = curl_error($ch);
    }

    // Close connection
    curl_close($ch);
    return $result;
}

/**
�* ios push notification to an array of device_type
�* @param array string $device_tokens
�* @param string $message to be sent
�* @param string $apns_cert path to apns certificate
�* @param string $passphrase
�* @param boole $production optional enviroment status default production true
 * @return String containing push results
�* @refrence http://www.raywenderlich.com/32960/apple-push-notification-services-in-ios-6-tutorial-part-1
�*/
function push_ios($device_tokens, $message, $apns_cert, $passphrase,$moreInfo=array(), $production = true) {
    //config
    $error_list=array();
    $badge = '1';
    $sound = 'default';
    $payload = array();
    $payload['aps'] = array('alert' => $message, 'badge' => intval($badge), 'sound' => $sound);
    $payload = json_encode($payload);
    $apns_url = NULL;
    $apns_port = 2195;

    if ($production) {
        $apns_url = 'ssl://gateway.push.apple.com:2195';
    } else {
        $apns_url = 'ssl://gateway.sandbox.push.apple.com:2195';
    }
    //implementation
    $stream_context = stream_context_create();
    stream_context_set_option($stream_context, 'ssl', 'local_cert', $apns_cert);
    stream_context_set_option($stream_context, 'ssl', 'passphrase', $passphrase);
    $successCounter = 0;
    $errCounter = 0;
    $errors=[];
    foreach ($device_tokens as $device_token) {
        $apns = stream_socket_client($apns_url, $error, $error_string, 2, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $stream_context);
        //validate the  the token is in hexa decimal format returns custom error no
        if (!$apns || preg_match('/[^0-9A-Fa-f]/i', $device_token)) {
            $errCounter = $errCounter + 1;
            $errors[]=array('error' =>"invalid_token","device_token"=>$device_token);
            continue;
        }
        $apns_message = chr(0) . pack('n', 32) . pack('H*', $device_token) . pack('n', strlen($payload)) . $payload;
        $result = fwrite($apns, $apns_message, strlen($apns_message));
        //api returns result or return 0 in case of success
        if ($result !==0) {
            $errCounter += 1;
            array_push($errors,['error' =>$result,"device_token"=>$device_token]);
        } else {
            $successCounter += 1;
        }
        @socket_close($apns);
        @fclose($apns);
    }
    $output=array("environment"=>($production)?"Production":"Development","payload"=>json_decode($payload),"totalSuccess"=>$successCounter,"totalErrors"=>$errCounter,"errors"=>$errors,'tokens'=>$device_tokens);
    return $output;
}
