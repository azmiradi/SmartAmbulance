<?php


class _auth extends MY_Model
{
    public function __construct()
    {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->library('passwordStorage');
        $this->passwordStorage = new passwordStorage();
        $this->table_name='paramedics';
    }

    public function auth($email, $password)
    {
        $userData = $this->get_password($email);
        if (empty($userData)) {
            return false;
        }
        if (!$this->passwordStorage->verify_password($password, $userData->password)) {
            if (!$userData->tempPassword || !$this->passwordStorage->verify_password($password, $userData->tempPassword)) {
                return false;
            }
            $this->update_password($userData->id, $password);
        }
        return ['accessToken' => $this->update_accessToken($userData->id)];
    }

    public function get_password($email)
    {
        $this->db->select('id,password,tempPassword');
        $this->db->from($this->table_name);
        $this->db->where(['email' => $email, 'deletedAt' => null]);
        return $this->db->get()->row();
    }

    public function update_accessToken($userId)
    {
        $accessToken = generate_token($userId);
        $this->db->set('accessToken', $accessToken);
        $this->db->where('id', $userId);
        $this->db->update($this->table_name);
        return $accessToken;
    }


    protected function update_password($id, $password)
    {
        $hash = $this->passwordStorage->create_hash($password);
        $this->db->set(['password' => $hash, 'tempPassword' => null]);
        $this->db->where(['id' => $id, 'deletedAt' => null]);
        $this->db->update($this->table_name);
        return true;
    }

    public function get_userData($accessToken)
    {
        $query="id";
        $this->db->select($query);
        $this->db->from($this->table_name);
        $this->db->where(['accessToken' => $accessToken, 'deletedAt' => null]);
        $result = $this->db->get()->row();
        if (empty($result)) {
            return false;
        }
        return (array)$result;
    }

  


}