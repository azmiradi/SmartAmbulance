<?php


class _hospital extends MY_Model
{
    public function __construct()
    {
        // Call the CI_Model constructor
        parent::__construct();
        $this->table_name='hospitals';
    }

    public function find_hospital($lat,$lng,$blood_type_id,$quantity)
    {
        //we can add extra logic to search for available bags from other types that can donate to target type
        $this->db->select("h.id,h.name,h.lat,h.long");
  $this->db->select("
		,(6371 * acos( cos( radians($lat) ) * cos( radians( h.lat ) ) * cos( radians( h.long ) - radians($lng) ) + sin( radians($lat) ) * sin( radians( h.lat ) ) ) ) AS distance
        ", false);        
		$this->db->from('blood_bags bb');
        $this->db->join($this->table_name.' h','h.id=bb.hospitals_id');
        $this->db->where(['bb.blood_types_id'=>$blood_type_id,'bb.quantity>'=>$quantity]);
		$this->db->order_by("distance", "asc");
        $hospital= $this->db->get()->row();
        if(empty($hospital)){
            return false;
        }
        $this->load->model('_order');
        $_order=new _order();
        $hospital->code= $_order->get_order_code($hospital->id,$blood_type_id,$quantity);
        return $hospital;
    }
}