<?php


class _blood_type extends MY_Model
{
    public function __construct()
    {
        // Call the CI_Model constructor
        parent::__construct();
        $this->table_name='blood_types';
    }
     
    public function get_entries()
    {
        $this->db->select('id,type');
        $this->db->from($this->table_name);
		return $this->db->get()->result();
    }
   
}