<?php


class _paramedic extends MY_Model
{
    public function __construct()
    {
        // Call the CI_Model constructor
        parent::__construct();
        $this->table_name='paramedics';
    }

    public function insert_entry($paramedic)
    {
        $this->load->library('passwordStorage');
        $passwordStorage = new passwordStorage();
        $paramedic['password'] = $passwordStorage->create_hash($paramedic['password']);
        $this->db->insert($this->table_name,$paramedic);
        $userId=$this->db->insert_id();
        $this->load->model('_auth');
        $_auth=new _auth();
        return $_auth->update_accessToken($userId);
    }

    public function check_email_availability($email)
    {
        $id=(isset($this->userData['id']))? $this->userData['id']:0;
        $this->db->select('id');
        $this->db->from($this->table_name);
        $this->db->where(['email' => $email, 'deletedAt' => null, 'id!=' => $id]);
        if ($this->db->get()->row()) {
            return false;
        }
        return true;
    }


}