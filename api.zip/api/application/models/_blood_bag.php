<?php


class _blood_bag extends MY_Model
{
    public function __construct()
    {
        // Call the CI_Model constructor
        parent::__construct();
        $this->table_name='blood_bags';
    }
    public function update_quantity($hospitalId,$bloodTypeId,$accumulatedQuantity){
        $this->db->set('quantity',"quantity+$accumulatedQuantity",false);
        $this->db->where(['hospitals_id'=>$hospitalId,'blood_types_id'=>$bloodTypeId]);
        $this->db->update($this->table_name);
    }
}