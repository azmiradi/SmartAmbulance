<?php


class _order extends MY_Model
{
    public function __construct()
    {
        // Call the CI_Model constructor
        parent::__construct();
        $this->table_name='orders';
    }
    public function get_order_code($hospitalId,$bloodTypeId,$requestedQuantity){
        $code=dechex((float)($this->userData['id'].$bloodTypeId.$hospitalId.$bloodTypeId.$requestedQuantity));
       //check for duplicated orders before ordering
        if(empty($this->get_entry($code))){
            //place an order
           $this->insert_entry($hospitalId,$bloodTypeId,$requestedQuantity,$code);
           /*we should handle here lock on orders from hospital storage/blood_bags
           to avoid negative values in case of concurrent orders while storage almost empty
           */
        }
        return $code;
    }
    public function validate_code($hospitalId,$code){
        $order=$this->get_entry($code,$hospitalId);
        if(empty($order)){
          return false;
        }
        $this->load->model('_blood_bag');
        $_blood_bag=new _blood_bag();
        $_blood_bag->update_quantity($hospitalId,$order->bloodTypeId,-$order->requestedQuantity);
        $this->confirm_delivery($code);
        return true;
    }
    private function get_entry($code,$hospitalId=null){
        $this->db->select('id,blood_types_id as bloodTypeId,requested_quantity as requestedQuantity');
        $this->db->from($this->table_name);
        $this->db->where(['code'=>$code,'deliveredAt'=>null]);
        if($hospitalId){
            $this->db->where('hospitals_id',$hospitalId);
        }
        return $this->db->get()->row();
    }
    private function insert_entry($hospitalId,$bloodTypeId,$requestedQuantity,$code){
        $order=['paramedics_id'=>$this->userData['id'],'hospitals_id'=>$hospitalId,'blood_types_id'=>$bloodTypeId,'requested_quantity'=>$requestedQuantity,'code'=>$code];
        $this->db->insert($this->table_name,$order);
    }

    private function confirm_delivery($code){
        $this->db->set('deliveredAt', 'CURRENT_TIMESTAMP', false);
        $this->db->where(['code'=>$code,'deliveredAT'=>null]);
        $this->db->update($this->table_name);
    }
}