<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class MY_Model extends CI_Model
{
    protected $table_name;
    protected $prefix;
    protected $userData;
    function __construct()
    {
        parent::__construct();
        $this->userData=$this->config->item('userData');
    }
    public function  getFriendlyDateTimeString($dateTimeColumn)
    {
        return "case when TIMESTAMPDIFF(MINUTE, $dateTimeColumn, now()) < 1 then 'Just Now'
		when TIMESTAMPDIFF(MINUTE, $dateTimeColumn, now()) = 1 then ' 1 min'
		when TIMESTAMPDIFF(HOUR, $dateTimeColumn, now()) < 1 then concat(TIMESTAMPDIFF(MINUTE, $dateTimeColumn, now()),' mins')
		when TIMESTAMPDIFF(HOUR, $dateTimeColumn, now()) = 1 then '1 hr'
		when TIMESTAMPDIFF(DAY, $dateTimeColumn, now()) < 1 then concat(TIMESTAMPDIFF(HOUR, $dateTimeColumn, now()),' hrs')
		when TIMESTAMPDIFF(DAY, $dateTimeColumn, now()) < 2 then DATE_FORMAT($dateTimeColumn,'Yesterday at %h:%i %p')
		when TIMESTAMPDIFF(YEAR, $dateTimeColumn, now()) < 1 then DATE_FORMAT($dateTimeColumn,'%M %d at %h:%i %p')
		else DATE_FORMAT($dateTimeColumn,'%M %d %Y at %h:%i %p')end ";
    }
}
