<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Migrations extends API_Controller
{

    function __construct()
    {
        parent::__construct();
    }

    function updateRecords_get()
    {
        $this->success_response();
    }
}
