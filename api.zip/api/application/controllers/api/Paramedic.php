<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Paramedic extends API_Controller
{

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        /*  $this->methods['login']['limit'] = 500; // 500 requests per hour per user/key
         */
    }

    public function register_post()
    {
        if (!$this->post('email') || !$this->post('password') || !$this->post('name')) {
            $this->error_response('missing_parameter');
        }
        if (!check_email($this->post('email'))) {
            $this->error_response('invalid_email');
        }
        $this->load->model('_paramedic');
        $_paramedic = new _paramedic();
        if (!$_paramedic->check_email_availability($this->post('email'))) {
            $this->error_response('duplicated_email');
        }
        $paramedic = ['email' => $this->post('email'), 'password' => $this->post('password'), 'name' => $this->post('name')];
        $accessToken = $_paramedic->insert_entry($paramedic);
        $this->success_response(['accessToken' => $accessToken]);
    }

    public function login_post()
    {
        if (!$this->post('email') || !$this->post('password')) {
            $this->error_response('missing_parameter');
        }
        if (!check_email($this->post('email'))) {
            $this->error_response('invalid_email');
        }
        $this->load->model('_auth');
        $_auth = new _auth();
        $uerData = $_auth->auth($this->post('email'), $this->post('password'));
        if (!$uerData) {
            $this->error_response('unauthenticated_request');
        }
        $this->success_response(['access_token' => $uerData['accessToken']]);
    }

    public function bloodTypes_get()
    {
        $this->load->model('_blood_type');
        $_blood_type = new _blood_type();
        $this->success_response(['blood_types' => $_blood_type->get_entries()]);
    }

    public function hospital_get()
    {
        $this->verifyAccess();
        if (!$this->get('lat') || !$this->get('long') || !$this->get('blood_type_id') || !$this->get('quantity')) {
            $this->error_response('missing_parameter');
        }

        $this->load->model('_hospital');
        $_hospital = new _hospital();
        $hospital = $_hospital->find_hospital($this->get('lat'), $this->get('long'), $this->get('blood_type_id'), $this->get('quantity'));
        if (empty($hospital)) {
            $this->error_response('no_records');
        }
        $this->success_response(['hospital' => $hospital]);
    }


    protected function verifyAccess()
    {
        $accessToken = null;
        if ($this->get('accessToken')) {
            $accessToken = $this->get('accessToken');
        } elseif ($this->post('accessToken')) {
            $accessToken = $this->post('accessToken');
        } else {
            $this->error_response('unauthenticated_request');
        }
        $this->load->model('_auth');
        $_auth = new _auth();
        $this->userData = $_auth->get_userData($accessToken);
        if (empty($this->userData)) {
            $this->error_response('unauthenticated_request');
        }
        $this->config->set_item('userData', $this->userData);
    }


}
