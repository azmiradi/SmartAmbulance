<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class hospital extends API_Controller
{

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        /*  $this->methods['login']['limit'] = 500; // 500 requests per hour per user/key
         */
    }
    public function validateCode_get(){
        if (!$this->get('hospitalId') || !$this->get('code')) {
            $this->error_response('missing_parameter');
        }
        $this->load->model('_order');
        $_order=new _order();
        if(!$_order->validate_code($this->get('hospitalId'),$this->get('code'))){
            $this->error_response('invalid_parameter');
        }
        $this->success_response();
    }

}
